
# Financial Chatbot (Flask Version)

## 📌 Functionality

This is a simple Flask web app that acts as a financial chatbot. It answers predefined questions about company financials for Apple, Microsoft, and Tesla (based on FY 2022–2024 data).

### 🔍 Supported Features:
- Users can type a question in the browser and get a financial response.
- Responds to 5 specific financial queries using hardcoded data.
- Easy to run with Flask: just install Flask and run `app.py`.

## ❗ Limitations

- Only supports **exact matches** to 5 predefined queries.
- Does **not support natural language understanding** or fuzzy matching.
- Does **not dynamically analyze data** — all responses are hardcoded.
- Limited to **command-line or local web interface** (no authentication or deployment).
- No persistent storage or logging — it's a demo bot.

## 💡 Future Improvements

- Add NLP support with spaCy or transformers to handle flexible questions.
- Use a vector store (like FAISS) for semantic search.
- Connect to a real-time database or financial API for live data.

## 🚀 How to Run

1. Make sure you have Python 3 and Flask installed:

```bash
pip install flask
```

2. Run the app:

```bash
python app.py
```

3. Open your browser and go to:

```
http://127.0.0.1:5000
```

Enjoy!
