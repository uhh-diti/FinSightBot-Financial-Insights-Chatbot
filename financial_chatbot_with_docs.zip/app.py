from flask import Flask, render_template, request

app = Flask(__name__)

responses = {
    "What is the total revenue for Apple in 2024?":
        "Apple's total revenue in 2024 was $391.04 billion.",
    "How did Tesla's net income change from 2023 to 2024?":
        "Tesla's net income dropped from $14.99B in 2023 to $7.09B in 2024 — a 52.7% decrease.",
    "Which company had the highest cash flow in 2024?":
        "Microsoft had the highest operating cash flow in 2024 with $118.45 billion.",
    "How much did Microsoft's revenue grow from 2023 to 2024?":
        "Microsoft's revenue grew from $198.27B in 2023 to $245.07B in 2024 — a 23.6% increase.",
    "What are Apple's total assets in 2024?":
        "Apple's total assets in 2024 were $364.98 billion."
}

@app.route("/", methods=["GET", "POST"])
def index():
    answer = ""
    if request.method == "POST":
        question = request.form["question"]
        answer = responses.get(question, "Sorry, I don't have an answer for that question.")
    return render_template("index.html", answer=answer)

if __name__ == "__main__":
    app.run(debug=True)
